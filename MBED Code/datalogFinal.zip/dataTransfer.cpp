#include "dataTransfer.h"
#include "HTTPClient.h"

void write()
{
    write_data = true;
}


char * storeData(int total_days, char * path)
{
   
    bool day_is_over = false;
    int  lines = 0; // number of lines to write
    
    
    pc.printf("\n\rDAY %d", total_days); // new day
    time_t current_time = time(NULL);
    pc.printf(", time : %s ", ctime(&current_time));  
    pc.printf("\n\rwriting file to %s ", path);
    
    // read values from ADCs 
     
     /*
     int ac_current1 = ADCread(1, 3);
     int ac_current2 = ADCread(2, 3);
     int ac_voltage1 = ADCread(3, 3);
     int ac_voltage2 = ADCread(4, 3);
     
     int dc_current1 = ADCread(1, 1);
     int dc_current2 = ADCread(2, 1);
     int dc_current3 = ADCread(3, 1);
     int dc_current4 = ADCread(4, 1); 
     
     
     int dc_voltage1 = ADCread(1, 2);
     int dc_voltage2 = ADCread(2, 2);
     int dc_voltage3 = ADCread(3, 2);
     int dc_voltage4 = ADCread(4, 2); */
     
    
    
     int ac_current1 = 430;
     int ac_current2 = 56;
     int ac_voltage1 = 60;
     int ac_voltage2 = 73;
     
     int dc_current1 = 0;
     int dc_current2 = 2;
     int dc_current3 = 23;
     int dc_current4 = 12;
     
     
     int dc_voltage1 = 11;
     int dc_voltage2 = 10;
     int dc_voltage3 = 99;
     int dc_voltage4 = 95; 
     
     
     
     pc.printf("\n\rACC 1 : %d ", ac_current1);
     pc.printf("\n\rACC 2 : %d ", ac_current2);
     pc.printf("\n\rACV 3 : %d ", ac_voltage1);
     pc.printf("\n\rACV 4 : %d ", ac_voltage2);
        
     pc.printf("\n\rDCC 1 : %d ", dc_current1);
     pc.printf("\n\rDCC 2 : %d ", dc_current2);
     pc.printf("\n\rDCC 3 : %d ", dc_current3);
     pc.printf("\n\rDCC 4 : %d ", dc_current4);
    
     pc.printf("\n\rDCV 1 : %d ", dc_voltage1);
     pc.printf("\n\rDCV 2 : %d ", dc_voltage2);
     pc.printf("\n\rDCV 3 : %d ", dc_voltage3);
     pc.printf("\n\rDCV 4 : %d ", dc_voltage4);
     
     
    char date[256];
    struct tm *tp;
    time_t curtime;
    time(&curtime);
    tp = localtime(&curtime);
    strftime(date, 256, "%d%b%Y", tp);
    
    
    // open file to write
    FILE * fp = fopen(path, "w");
    fprintf(fp, "Date : %s\n", date);
    /*fprintf(fp, "\nACcurrent1      ACcurrent2      ACvoltage1      ACvoltage2");
    fprintf(fp, "      DCcurrent1      DCcurrent2      DCcurrent3      DCcurrent4");
    fprintf(fp, "      DCcoltage1      DCvoltage2      DCvoltage3      DCvoltage4\n"); */
    fprintf(fp, "ACC1\t\t\tACC2\t\t\tACV1\t\t\tACV2\t\t\tDCC1\t\t\tDCC2\t\t\tDCC3\t\t\tDCC4\t\t\t");
    fprintf(fp, "DCV1\t\t\tDCV2\t\t\tDCV3\t\t\tDCV4\n");
    pc.printf("\n\rstarting to write...");
  
    // initiate interrupt to write to file periodically
    file_interrupt.attach(&write, SAMPLE_TIME);
    while ( !day_is_over ) 
    {
  
        if ( lines >= 30 ) {
           day_is_over =  true;
           file_interrupt.detach();
  
        }
        
        if( write_data && !day_is_over)
        {
            file_interrupt.detach();
            lines++;
                          
            pc.printf("\n\rline %d ", lines);
           
            fprintf(fp, "\n%d\t\t\t",ac_current1);
            fprintf(fp, "%d\t\t\t",  ac_current2);
            fprintf(fp, "%d\t\t\t",  ac_voltage1);
            fprintf(fp, "%d\t\t\t",  ac_voltage2);
            
            fprintf(fp, "%d\t\t\t" , dc_current1);
            fprintf(fp, "%d\t\t\t",  dc_current2);
            fprintf(fp, "%d\t\t\t",  dc_current3);
            fprintf(fp, "%d\t\t\t",  dc_current4);
            
            
            fprintf(fp, "%d\t\t\t" , dc_voltage1);
            fprintf(fp, "%d\t\t\t",  dc_voltage2);
            fprintf(fp, "%d\t\t\t",  dc_voltage3);
            fprintf(fp, "%d\n",      dc_voltage4); 
           
              
            // restart the interrupt for the next file write
            write_data = false;
            file_interrupt.attach(&write, SAMPLE_TIME);             
        }
    }
    fclose(fp);
    
    // Now reading file
    pc.printf("\n\rReading file...");
    FILE * fp1 = fopen(path, "r");
 
    
    if( fp1 != NULL) 
    {
        
        char * buffer = (char *)malloc(MAXLINES);
        strcpy(buffer, "");
        char temp[100];
        int new_lines = 0;
        

        // Copying file content to buffer
        while(fgets(temp, 60, fp) != NULL)
        {
          new_lines++;
         // pc.printf("%s", temp);
        
          if( new_lines >= 6)
             strcat(buffer, temp);
        
        }

        fclose(fp1);   
        return buffer; 
    }

    else 
        pc.printf("couldn't open file\n");
     
}

void sendData(void const* ) 
{
      
      while(1) {
      
        // upload data regularly
        while(1) 
        { 
            mutex.lock();
            if(finished_storing) {
                mutex.unlock();
                break;
            }
            mutex.unlock();
        } 
        
        
       
       
        
        char temp[] = "4.5 3.2 5.3 4.5 6.3 0.4 7.3 8.2 9.2 10.0 11.1 12.1";
        
         //POST data
        HTTPClient http;
        HTTPMap message; // data to send
        
        char str[512];
        HTTPText reply(str, 512);
        message.put("measurements" , temp); // map name to file
        pc.printf("\n\rTrying to post data...\n");
        pc.printf("\n\rdata: %s", temp);
        pc.printf("\n\rData that will be sent: %d bytes", strlen(temp) );
    
        timer.start();
        int ret = http.post("http://davidfirstapp.appspot.com/sensors", message, &reply);
        timer.stop();
    
        if (!ret)
        {
            //light up second LED
            upload_status = 1;
            sent = true;
            pc.printf("\n\rExecuted POST successfully - read %d characters\n", strlen(str));
            pc.printf("\n\rResult: %s\n", str);
        }
        else
            pc.printf("\n\rError : ret = %d \n\r HTTP return code = %d\n", ret, http.getHTTPResponseCode());
    
    
        free(data);
    
        
        // lock the "finished_uploading" variable to prevent the main thread
        // from accessing it at the same time
        mutex.lock();
        finished_uploading = true; 
        mutex.unlock();
        Thread::wait(20000);
        pc.printf("\n\rFinished waiting");
     }
  
     
}