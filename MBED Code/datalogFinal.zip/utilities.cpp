#include "utilities.h"

void createPaths( char filePath[], char  logPath[], char date[]){
    char dirPath[100]; // path to directory
    
    //create file dir path
    strcpy(dirPath, "/sd/days");
    // make directory       
    mkdir(dirPath, 0777); 
    
    // create dataFile
    strcpy(filePath, dirPath);
    strcat(filePath, "/");
    strcat(filePath , date);
    strcat(filePath , ".txt");
    

    
    // create log dir path
    strcpy(dirPath, "/sd/log");
     mkdir(logPath, 0777);
    
    strcpy(logPath,  dirPath);
    strcat(logPath, "/");
    strcat(logPath , date);
    strcat(logPath , ".txt");
    

    

}
char * convertData(char * buffer, int size)
{
    int whiteSpace = 0;
    int i = 0;
    int j = 0;
    
   
    
    char * data = (char *)malloc( size);

    
      // start reading from the second line
  
           while ( i < size )
           {
                if (buffer[i] != '\t' && buffer[i] !='\n' && buffer[i] != ' ') // if there's no space
                {
                     if(whiteSpace) // ...but there was a space previously 
                     {
                    
                         whiteSpace = 0;
                          data[j] = ' ';
                          j++;
                          
                     }
                            
                          data[j] = buffer[i];
                          j++;
                }
                    
                else // don't add anything to data
                        whiteSpace = 1;
                
                        
                        i++;
            } 
            
            return data;   
} 

// configure time manually
struct tm * configure_time()
{

     
     struct tm * t = (struct tm*)malloc(sizeof(struct tm));
     int datetime[6]; // stores the 6 date elements
     int var;
     char buffer[10];
     int i = 0;
     
     // get the current time from terminal 
     pc.printf("\rEnter current date and time:\n");
     pc.printf("\rYYYY MM DD HH MM SS[enter]\n\r");
    
        // write input data to array
        while(1) {
   
            // read keyboard input
            char c = pc.getc();    
        
            if( c != 'e')
                pc.putc(c);
     
            // detected space -> add number to array
            if( c== ' ' || c == 'e') {
                var = atoi(buffer);
                datetime[i] = var;
                strcpy(buffer, "");
                i++;
            
            // if a newline is detected we're done...
            if(c == 'e')
              break;
            }
        
            else // other characters just concatenate them
            {
                int len = strlen(buffer);
                buffer[len] = c;
                buffer[len + 1] = '\0';

            }          
        }// end while(1)

 
     
    // set up date
    t->tm_year = datetime[0];
    t->tm_mon = datetime[1];
    t->tm_mday = datetime[2];
    t->tm_hour = datetime[3];
    t->tm_min = datetime[4];
    t->tm_sec = datetime[5];   
     
                    
     t->tm_year = t->tm_year - 1900;
     t->tm_mon = t->tm_mon -1;
     
     // set the time 
     set_time(mktime(t));

     return t;

}

/** fetches timestamp for any specified time zone
 from the GAE web server 
 */
 
int getServerTime()
{
    char Time[50];
    HTTPClient http;
    
    pc.printf("\n\rTrying to fetch page...");
    int ret = http.get("http://davidfirstapp.appspot.com/time?offset=1", Time, 40);
    
    if(!ret) 
        pc.printf("\n\rPage fetched successfully");
        
    
    else
      pc.printf("\rError ,ret = %d \n\r HTTP return code = %d\n", ret, http.getHTTPResponseCode());
     
     
    int IntTime = atoi(Time);
    return IntTime;
    

}


// save extra information in log
void log(int total_days, char * path, struct connectivityState state)
{
  
  char buffer[1000];
  char tmp[200];
  strcpy(buffer, "");
  
  
  if(state.connected) {
    strcat( buffer,"connection : successful\n\r");
    sprintf(tmp, "connection time : %d seconds\n\r", state.connectionTime);
    strcat(buffer, tmp);
   
    
    
    switch(state.Bearer) {
    
        case 0 : strcat( buffer, "connection type: Unknown\n\r");
        break;
        
        case 1: strcat( buffer, "connection type: GSM (2G) \n\r");
        break;
        
        case 2: strcat(buffer, "connection type: EDGE (2.5G)\n\r");
        break;
        
        case 3 : strcat(buffer,"connection type: UMTS (3G) \n\r");
        break;
        
        case 4 : strcat(buffer,"connection type: HSPA (3G+) \n\r");
        break;
    
    
    }
    
    switch(state.RegistrationState) {
        case 0: strcat(buffer, "registration state : Unknown\n\r");
        break;
        
        case 1: strcat(buffer, "registration state : Registering\n\r");
        break;
        
        case 2: strcat(buffer, "registration state : Denied\n\r");
        break;
        
        case 3: strcat(buffer,"registration state : No signal\n\r");
        break;
        
        case 4: strcat(buffer, "registration state : Registered on Home Network\n\r");
        break;
        
        case 5: strcat(buffer,"registration state : Registered on Roaming Network unknown\n\r");
        break;
    
    
    }
    switch( state.Rssi) {
      case 0 : strcat(buffer, "rssi : unknown\n\r");
      break;
      
      default : sprintf(tmp,"rssi : %ddbm\n\r", state.Rssi); 
                strcat(buffer, tmp);
      break;
    
    
    }
    
    if(state.sent){
        strcat(buffer,"upload : successful\n\r");
        sprintf(tmp,"data sent : %d bytes\n\r", strlen(data));
        strcat(buffer, tmp);
        sprintf(tmp,"server response time: %d seconds\n\r ", state.uploadTime);
        strcat(buffer, tmp);
         
    }
      
    else
        strcat(buffer,"upload : unsuccessful\n\r");
  }
    
  
  else
   strcat(buffer, "connection : unsuccessful\n");
   
   pc.printf("\n\r%s", buffer);
   
   FILE * fp = fopen( path, "w");
   fprintf(fp, "%s", buffer);
   fclose(fp);
  
  // send log information
  HTTPClient client;
  HTTPMap  message; // data to send
  char output[512];  
  HTTPText reply(output, 512); // server reply
  message.put("e.quinoxlog", buffer);
  
  pc.printf("\n\rTrying to post log...\n\r");
  int ret = client.post("http://davidfirstapp.appspot.com/log", message, &reply);
  
  if (!ret)
  {
  
       pc.printf("\n\rExecuted POST successfully - read %d characters\n", strlen(output));
       pc.printf("\n\rResult: %s\n", output);
  }
  else
       pc.printf("\n\rError : ret = %d \n\r HTTP return code = %d\n", ret, client.getHTTPResponseCode());
  pc.printf("\n\rfinish sending log");
    
   

}

/** Set the RTC from the Internet time
*/


void ntpInternetTime() 
{
    NTPClient ntp;
    time_t InternetTime;
    
    if (ntp.setTime("0.pool.ntp.org") == 0)
    {
        pc.printf("\n\rManaged to set time successfully");  
        InternetTime += 3600;  
        InternetTime = time(NULL);
        pc.printf("\n\rInternet timestamp %d ", InternetTime);
        pc.printf("\n\rInternet time as basic string %s \n ", ctime(&InternetTime));
        
      
    }


} 