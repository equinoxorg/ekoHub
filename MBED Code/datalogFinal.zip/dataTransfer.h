#ifndef data_header
#define data_header

#include "mbed.h"
#include "rtos.h"
#include "ADC_file.h"

#define SAMPLE_TIME 1.0

const int MAXLINES = 100;

extern char * data;
extern bool write_data;
extern bool finished_storing;
extern bool finished_uploading;
extern bool sent;
extern Mutex mutex;
extern Serial pc;
extern Timeout file_interrupt;
extern Timer timer;
extern DigitalOut upload_status;

void write();
void sendData(void const* arg);
char * storeData(int total_days, char * path);

#endif