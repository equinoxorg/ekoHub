#include "mbed.h"
#include "VodafoneUSBModem.h"
#include "HTTPClient.h"
#include "SDFileSystem.h"
#include "utilities.h"
#include "ADC_file.h"
#include "dataTransfer.h"
#include "link/LinkMonitor.h"


Serial pc(USBTX, USBRX);
Timeout file_interrupt;
Timer timer; // times
Mutex mutex;
DigitalOut led(LED1);
DigitalOut upload_status(LED2);



// functions
char * data;



// constants
#define TIMEOUT 5 // secs
#define THRESHOLD 1800;


// flags
bool day_is_over;
bool write_data;
bool  sent; // indicates if data was uploaded
bool finished_uploading;
bool finished_storing;



int main()
{


  //VT100 erase screen
  pc.printf("\x1B[2J");    
  pc.printf("\rStart! ");
 

   int  current_day, total_days, year, attempts, month = 0;
   char * buffer; 
   VodafoneUSBModem modem; 
   
   /*
   initiate thread for uploading data later. This must be executed as
   a separate program to control memory and process requirements */
   Thread upload(sendData, NULL, osPriorityNormal, 1024 * 4);
 
   pc.printf("\n\rTrying to connect...");
   modem.connect("pp.vodafone.co.uk");
   pc.printf("\n\rGetting ntp internet time");
   ntpInternetTime();
   modem.disconnect();
   
 
   char date[256];
   struct tm *tmp;
   time_t curtime;
   time(&curtime);
   tmp = localtime(&curtime);
   
   pc.printf("\n\r");
   strftime(date, 256, "%d%b%Y", tmp);
   pc.printf("%s\n", date);
  
  
  SDFileSystem sd(p5, p6, p7, p8, "sd");
  // main code
  while( attempts < 1) 
  { 
  
    

  
    led = 0;
    upload_status = 0;
    day_is_over = false;
    write_data = false;
    finished_uploading = false;
    finished_storing = false;
    sent = false;
    
    // A new day starts...
    total_days++;
   
   
    char filePath[100]; // path to file
    char logPath[100]; // path to log

    
   createPaths(filePath, logPath, date); 
   pc.printf("\n\rfile path is : %s\n", filePath);
   pc.printf("\n\rlog path is : %s\n", logPath);
    
    /* write data continuously to the file during the day
     then read this data into a buffer; */
     buffer = storeData(total_days, filePath);
  
    // change data into appropriate format for transfer
     data = convertData(buffer, MAXLINES);
    //pc.printf("\n\rdata is %s\n", data);
    //pc.printf("\n\rData to send: %d bytes", strlen(data) );
    int j = 0;
    
  
     
    // Open a 3G connection
    pc.printf("\n\rTrying to connect");
    
    // time connection setup
    timer.start();
    int ret = modem.connect("pp.vodafone.co.uk");
    timer.stop();
    
    // get state
    struct connectivityState connectivityState;
    int  Rssi;
    LinkMonitor::REGISTRATION_STATE RegistrationState;
    LinkMonitor::BEARER Bearer;
    int linkstate = modem.getLinkState(Rssi, RegistrationState, Bearer);

    
    // get link state info
    if ( !linkstate ) 
    {
      connectivityState.Rssi = Rssi;
      connectivityState.RegistrationState = RegistrationState;
      connectivityState.Bearer = Bearer;
     
    } 
   
    // read connection time
    connectivityState.connectionTime = timer.read();
    if(ret){
         pc.printf("\n\rCould not connect\n");
         return;
    }
    
    else
     connectivityState.connected = true;
    
    
    mutex.lock();
    finished_storing = true;
    mutex.unlock();
     
    // wait until upload is finished or timeout has reached
    while(1) 
    { 
      /* lock the "upload_is_finished" variable to prevent the other thread
       from accessing it at the same time. */
        mutex.lock();
        if(finished_uploading) {
            mutex.unlock();
            break;
         }
        mutex.unlock();
    } 
    
    pc.printf("\n\rRepeat");  
    attempts++;

    connectivityState.sent = sent;
    connectivityState.uploadTime = timer.read();
   // log(total_days, logPath, connectivityState); // write all the log
  
    pc.printf("\n\rAfter log");
    modem.disconnect();
    
    free(data);
    led = 1;
  } // end while (1)
  
  
  free(time);
  upload.terminate();
  pc.printf("\n\rFinish");
    
}






