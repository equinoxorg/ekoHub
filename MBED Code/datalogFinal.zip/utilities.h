#ifndef utilities_header
#define utilities_header

#include "mbed.h"
#include "HTTPClient.h"
#include "NTPClient.h"
#include "link/LinkMonitor.h"

extern Serial pc;
extern char * data;

char * convertData(char * buffer, int size);
struct tm * configure_time();
int get_server_time();
void ntpInternetTime(); // get UTC timestamp
void log(int total_days, char * path, struct connectivityState state);
void createPaths( char filePath[], char  logPath[], char date[]);

struct connectivityState {
   bool connected;
   bool sent;
   int connectionTime;
   int uploadTime;
   int  Rssi;
   LinkMonitor::REGISTRATION_STATE RegistrationState;
   LinkMonitor::BEARER Bearer;
    

};

#endif